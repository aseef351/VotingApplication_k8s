---------------------
Python 2
---------------------
1) Set up MySQL
2) Import database schema (.sql file) into MySQL
3) Install libmysqlclient-dev
4) Run 'pip install -r requirements.txt' to install required modules
5) Change database credentials (See function get_connection())
6) Run app.py 
7) Connect to localhost:5000 on your web browser
8) The CSS file gridwork-done.css has stylesheets for the grid display used in the website. This file can be left as it is.
